package com.dictionary.service;

import org.junit.Test;
import org.mockito.InjectMocks;
import org.springframework.mock.web.MockMultipartFile;

import com.dictionary.DictionaryApplicationTests;

public class DictionaryServiceTest extends DictionaryApplicationTests {
	
	@InjectMocks
	private DictionaryService dictionaryService;
	
	@Test
	public void testSaveFile() throws Exception {
		MockMultipartFile multipartFile = new MockMultipartFile("file", "test.txt","text/plain", "Spring Framework Spring".getBytes());
		dictionaryService.saveFile(multipartFile);
	}
	
	@Test
	public void testSearchWord() throws Exception {
		dictionaryService.searchWord("Sanjeev");
	}
	
	@Test
	public void testSearchWordNotFound() throws Exception {
		dictionaryService.searchWord("Sanjeev");
	}
}