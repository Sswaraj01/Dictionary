package com.dictionary.controller;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.multipart.MultipartFile;

import com.dictionary.DictionaryApplicationTests;
import com.dictionary.service.DictionaryService;

public class DictionaryControllerTest extends DictionaryApplicationTests{
	
	
	@Mock
	private DictionaryService dictionaryService;
	
	
	@InjectMocks
	private DictionaryController dictionaryController;
	
	private MockMvc mockMvc;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(dictionaryController).build();
	}
	
	@Test
	public void testUploadDictionary() throws Exception {
		MockMultipartFile multipartFile = new MockMultipartFile("file", "test.txt","text/plain", "Spring Framework".getBytes());
		Mockito.when(dictionaryService.saveFile(Mockito.any(MultipartFile.class))).thenReturn("Success");
		RequestBuilder requestBuilder = MockMvcRequestBuilders.multipart("/dictionary/upload").file(multipartFile);
		mockMvc.perform(requestBuilder).andExpect(status().is(200));
	}
	
	@Test
	public void testUploadDictionaryNotAccepted() throws Exception {
		MockMultipartFile multipartFile = new MockMultipartFile("file", "test.pdf","application/pdf", "Spring Framework".getBytes());
		Mockito.when(dictionaryService.saveFile(Mockito.any(MultipartFile.class))).thenReturn("Success");
		RequestBuilder requestBuilder = MockMvcRequestBuilders.multipart("/dictionary/upload").file(multipartFile);
		mockMvc.perform(requestBuilder).andExpect(status().is(406));
	}
	
	@Test
	public void testSearchWord() throws Exception {
		Mockito.when(dictionaryService.searchWord(Mockito.any(String.class))).thenReturn("Success");
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/dictionary/search/testString");
		mockMvc.perform(requestBuilder).andExpect(status().is(200));
	}

}
