package com.dictionary.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.dictionary.constant.DictionaryConstant;

/**
 * In this service class all  logical operation will be done.
 * @author Sanjeev
 *
 */
@Service
public class DictionaryService {
	
	Map<String,Integer> dictMap = new HashMap<>();
	/**
	 * Method will help to process text file.
	 * @param  MultipartFilefile
	 * @return String
	 */
	@SuppressWarnings("resource")
	public String saveFile(MultipartFile file) {
		
		InputStream fileInput = null;
		Scanner sc =null;
		try {
			fileInput = file.getInputStream();
			sc = new Scanner(fileInput).useDelimiter(DictionaryConstant.WHITE_SPACE);
			int i =0;
			while(sc.hasNext()) {
				String sb =sc.next().replace(DictionaryConstant.COMMA_STRING, DictionaryConstant.EMPTY_STRING);
				sb=sb.replace(DictionaryConstant.FULLSTOP_STRING, DictionaryConstant.EMPTY_STRING);
				if(!dictMap.containsKey(sb)){
					dictMap.put(sb.toString(), i);
				}
				++i;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			sc.close();
			try {
				fileInput.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return DictionaryConstant.SUCESS_UPDATE;
	}

	/**
	 * It will search that all string available or not.
	 * @param String word
	 * @return String status
	 */
	public String searchWord(String word) {
		
		if(dictMap.containsKey(word)){
			return DictionaryConstant.SUCCESS_FOUND_WORD;
		}else {
			return DictionaryConstant.NOT_FOUND_WORD;
		}
	}
	
}
