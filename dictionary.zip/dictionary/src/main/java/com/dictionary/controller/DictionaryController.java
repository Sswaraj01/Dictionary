package com.dictionary.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.dictionary.constant.DictionaryConstant;
import com.dictionary.constant.UrlConstant;
import com.dictionary.service.DictionaryService;

/**
 * This is controller to do end-point mapping
 * @author Sanjeev
 *
 */
@RestController
@RequestMapping(value = UrlConstant.DICTIONARY_SERVICE_URL)
public class DictionaryController {
	
	private static final Logger log = LoggerFactory.getLogger(DictionaryController.class);
	
	@Autowired
	private DictionaryService dictionaryService;
	
	/**
	 * End point will help to upload text file.
	 * @param MultipartFile file
	 * @return String status
	 */
	@PostMapping(value = UrlConstant.DICTIONARY_UPLOAD_URL)
	public ResponseEntity<String> uploadDictionary(@RequestPart MultipartFile file) {
		
		String response =null;
		String fileType = file.getContentType();
		if(fileType.equalsIgnoreCase(DictionaryConstant.FILE_TYPE)) {
			log.info(fileType+" is  accepted");
			response = dictionaryService.saveFile(file);
		}else {
			log.info(fileType+" is not accepted");
			response = fileType+DictionaryConstant.IS_NOT_AACCEPTED;
			return new ResponseEntity<String>(response, HttpStatus.NOT_ACCEPTABLE);
		}
		return new ResponseEntity<String>(response, HttpStatus.OK);
	}
	
	/**
	 * End point will help to upload text file.
	 * @param MultipartFile file
	 * @return String status
	 */
	@GetMapping(value = UrlConstant.SEARCH_WORD_URL)
	public ResponseEntity<String> searchWord(@PathVariable(DictionaryConstant.WORD) String word) {
		return new ResponseEntity<String>(dictionaryService.searchWord(word), HttpStatus.OK);
	}

}
