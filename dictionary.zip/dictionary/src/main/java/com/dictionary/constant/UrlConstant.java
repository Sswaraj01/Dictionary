package com.dictionary.constant;

import org.springframework.stereotype.Component;

/**
 * This class contain all Service end point
 * @author Sanjeev
 *
 */
@Component
public class UrlConstant {
	
	public static final String DICTIONARY_SERVICE_URL ="/dictionary";
	public static final String DICTIONARY_UPLOAD_URL ="/upload";
	public static final String SEARCH_WORD_URL = "/search/{word}";
	
}
