package com.dictionary.constant;

import org.springframework.stereotype.Component;

/**
 * This class contain all constants related to  dictionary application
 * @author Sanjeev
 *
 */
@Component
public class DictionaryConstant {
	
	public static final String FILE_TYPE ="text/plain";
	public static final String FILE ="file";
	public static final String WORD = "word";
	public static final String SUCESS_UPDATE = "Successfully update.";
	public static final String WHITE_SPACE = " ";
	public static final String COMMA_STRING = ",";
	public static final String EMPTY_STRING = "";
	public static final String FULLSTOP_STRING = ".";
	public static final String SUCCESS_FOUND_WORD = "Success! word found in dictonary";
	public static final String NOT_FOUND_WORD = "Sorry! word is not available in dictonary";
	public static final String IS_NOT_AACCEPTED =  " is not accepted";
	
}
